<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

    <!-- Google Fonts-->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;700&display=swap" rel="stylesheet">

    <!-- My Style-->
    <link rel="stylesheet" href="css/styles.css">

    <!-- Logo Title Bar -->
    <link rel="icon" href="img/Logo.png" type="image/x-icon">
    <!-- <script src="https://cdn.tailwindcss.com"></script> -->



    <title>Macco.id</title>
</head>

<body>

    <!-- Navbar -->
    <?php include 'header.php';?>

<!-- Hero Section -->
<section id="hero" class="">
    <div class="container h-100">
        <div class="row h-100">
            <div class="col-md-6 hero-tagline my-auto">
                <h1>Membantu Temukan 
                    Venue Terbaik</h1>
                <p><span class="fw-bold">Macco </span>hadir untuk memudahkan anda dalam menemukan venue olahraga terbaik yang sesuai dengan kebutuhan dan keinginan anda</p>

            <button class="button-lg-secondary ">Temukan Venue</button>
            <a href="#">
                <img src="img/button arrow.png" alt="">
            </a>
            </div>
        </div>
        <img src="img/3588-removebg 1.png" alt="" class="position-absolute end-0 bottom-0 img-hero">
    </div>
</section>

<!-- Venue Section -->
<section id="VENUE">
    <div class="container">
        <div class="row">
            <div class="col-12 text-center">
                <h2>Pilih Cabang Olahraga</h2> 
                <span class="sub-title">Pilih Cabang Olahraga Yang Ingin Anda Cari</span>          
            </div>
        </div>
        <div class="mx-auto my-3 px-4">
            <div class="row d-flex w-100 px-5 mx-auto ">
                <div class="card mx-3 ms-4" style="width: 17rem;">
                    <img src="img/basket.png" class="card-img-top" alt="...">
                    <div class="card-body">
                      <h3 class="card-text text-center">Basket</h3>
                    </div>
                  </div>
                  <div class="card mx-4" style="width: 17rem;">
                    <img src="img/bultang.png" class="card-img-top" alt="...">
                    <div class="card-body text-center">
                      <h3 class="card-text">Badminton</h3>
                    </div>
                  </div>
                  <div class="card mx-3" style="width: 17rem;">
                    <img src="img/sepak.png" class="card-img-top" alt="...">
                    <div class="card-body text-center">
                      <h3 class="card-text">Futsal</h3>
                    </div>
                  </div>
            </div>
        </div>
    </div>
</section>


<!-- Rekomendasi -->
<section id="VENUE">
    <div class="container">
        <div class="row">
            <div class="col-12 text-center">
                <h2>Rekomendasi Venue Anda</h2>       
            </div>
        </div>
        <div class="mx-auto my-3 px-4">
            <div class="row d-flex w-100 px-5 mx-auto ">
                <div class="card mx-3 ms-4" style="width: 17rem;">
                    <img src="img/rush.png" class="card-img-top" alt="...">
                    <div class="card-body">
                      <h4 class="card-text ">Rush Academy</h4>
                      <p class="card-text">Jalan Kalimantan X No.39 Sumbersari.</p>
                      <p class="text-danger">Sewa</p>
                         <a href="#" class="btn btn-primary">Selengkapnya >>></a>
                    </div>
                    </div>
                  <div class="card mx-4" style="width: 17rem;">
                    <img src="img/elpashindo.png" class="card-img-top" alt="...">
                    <div class="card-body">
                      <h4 class="card-text">Zona Futsal</h4>
                      <p class="card-text">Jln Semeru XII No.09 Sumberbaru.</p>
                      <p class="text-danger">Sewa</p>
                        <a href="#" class="btn btn-primary">Selengkapnya >>></a>
                    </div>
                  </div>
                  <div class="card mx-3" style="width: 17rem;">
                    <img src="img/zona futsal.png" class="card-img-top" alt="...">
                    <div class="card-body">
                      <h4 class="card-text">Zona Futsal</h4>
                      <p class="card-text">Jln Karimata IV No.65 Ambulu Jember</p>
                      <p class="text-danger">Sewa</p>
                        <a href="#" class="btn btn-primary">Selengkapnya >>></a>
                    </div>
                  </div>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="mx-auto my-3 px-4">
            <div class="row d-flex w-100 px-5 mx-auto ">
                <div class="card mx-3 ms-4" style="width: 17rem;">
                    <img src="img/basket.png" class="card-img-top" alt="...">
                    <div class="card-body">
                      <h3 class="card-text ">Basket</h3>
                      <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                    <a href="#" class="btn btn-primary">Go somewhere</a>
                    </div>
                  </div>
                  <div class="card mx-4" style="width: 17rem;">
                    <img src="img/bultang.png" class="card-img-top" alt="...">
                    <div class="card-body ">
                      <h3 class="card-text">Badminton</h3>
                      <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                        <a href="#" class="btn btn-primary">Go somewhere</a>
                    </div>
                  </div>
                  <div class="card mx-3" style="width: 17rem;">
                    <img src="img/sepak.png" class="card-img-top" alt="...">
                    <div class="card-body ">
                      <h3 class="card-text">Futsal</h3>
                      <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                        <a href="#" class="btn btn-primary">Go somewhere</a>
                    </div>
                  </div>
            </div>
        </div>
    </div>
</section>

<div id="carouselExampleAutoplaying" class="carousel slide w-75 mx-auto mb-5 " data-bs-ride="carousel">
  <div class="carousel-inner ">
    <div class="carousel-item active">
      <img src="img/1.jpg" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="img/2.jpg" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="img/3.jpg" class="d-block w-100" alt="...">
    </div>
  </div>
  <button class="carousel-control-prev " type="button"  data-bs-target="#carouselExampleAutoplaying" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleAutoplaying" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>

    <!-- Footer -->
    <?php include 'footer.php';?>

    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p"
        crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
    -->
</body>

</html>