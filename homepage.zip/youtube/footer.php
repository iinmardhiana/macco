<div class="Footer px-5" style="background-color: #8F0019;">
        <div class="py-4 mx-auto">
          <ul class="d-inline-block list-unstyled text-white nav-underline mx-auto  ">
            <li class="nav-item">
              <a class="nav-link text-white" aria-current="page" href="#">Kebijakan dan Privasi pengguna</a>
            </li>
            <li class="nav-item">
              <a class="nav-link text-white" href="#">Tentang Kami</a>
            </li>
            <li class="nav-item">
              <a class="nav-link text-white" href="#">Hubungi Kami</a>
            </li>
          </ul>
        </div>
        <div class="">
          <div class="d-flex text-white ">
            <!-- <img src="/image/Logo ITCourse.png" width="130" height="50" alt=""> -->
            <div class="d-flex my-auto mx-auto">
              <img class="mx-1" src="/image/tdesign_copyright.png" width="24" height="24" alt="">
              <h5>2023 Copyright Macco</h5>
            </div>
          </div>
        </div>
      </div> 

