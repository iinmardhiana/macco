

        <!-- <section class="home">
             <div style="--swiper-navigation-color: #fff; --swiper-pagination-color: #fff" class="swiper bg-slider">
                <div class="swiper-wrapper">
                  <div class="swiper-slide">
                    <img src="img/1.jpg" alt="">
                    <div class="text-content">
                        <h2 class="title">PROMO DISCOUNT 40%<span> Basket Ground</span></h2>
                        <p> Lorem, ipsum dolor sit amet consectetur adipisicing elit. Autem assumenda aliquid perspiciatis consectetur consequuntur, veniam voluptas aperiam nulla! Nulla debitis quidem ab exercitationem beatae nihil similique provident ducimus laudantium hic? Perspiciatis voluptates placeat, delectus alias quis facilis excepturi, eveniet autem consectetur odio repellat numquam asperiores consequatur facere perferendis, veritatis sint!</p>
                        <button class="read-btn">Selengkapnya <i class="uil uil-arrow-right"></i></button>
                    </div>
                  </div>
                  <div class="swiper-slide">
                    <img class="w-100" src="img/2.jpg" alt="">
                    <div class="text-content">
                        <h2 class="title">GRAND OPENING 11.11<span> Futsal Ground</span></h2>
                        <p> Lorem ipsum dolor sit amet consectetur adipisicing elit. Vitae eaque veritatis ipsam aspernatur iusto voluptatibus earum, nulla dolorem incidunt, praesentium provident harum neque repellendus nostrum hic velit saepe fugit. At a reprehenderit laborum fuga veritatis et deserunt quo, nobis non minus voluptatum voluptas officia dolore rerum sequi modi obcaecati. Blanditiis.</p>
                        <button class="read-btn">Selengkapnya <i class="uil uil-arrow-right"></i></button>
                    </div>
                  </div>
                  <div class="swiper-slide">
                    <img class="w-100" src="img/3.jpg" alt="">
                    <div class="text-content">
                        <h2 class="title">MACO JAYA<span> Badminton Sehat</span></h2>
                        <p> Lorem ipsum, dolor sit amet consectetur adipisicing elit. Beatae iste eius enim repellendus, quae, dignissimos blanditiis recusandae eaque similique aliquid dolores consequatur consequuntur non cum odit. Vel, eius? Reiciendis adipisci minus aspernatur, dignissimos sunt minima! Qui accusamus illum in consequuntur!</p>
                        <button class="read-btn">Selengkapnya <i class="uil uil-arrow-right"></i></button>
                    </div>
                  </div>
                </div>
              </div>
              <div class="swiper-button-next"></div>
              <div class="swiper-button-prev"></div>
              <div class="bg-slider-thumbs">
                <div class="swiper-wrapper thumbs-container">
                  <img class="w-100" src="img/1.jpg" class="swiper-slide" alt="">
                  <img class="w-100" src="img/2.jpg" class="swiper-slide" alt="">
                  <img class="w-100" src="img/3.jpg" class="swiper-slide" alt="">
                  </div>
                </div>
              </div>
        </section> -->

        <script src="JS/swiper-bundle.min.js"></script>
        <script src="JS/main.js"></script>